<?php


// Create a database connection (adjust credentials accordingly)
$servername = "localhost";
$username = "id21132821_session";
$password = "4444@Four";
$dbname = "id21132821_info";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data from the usertbl table
$query = "SELECT * FROM usertbl";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $userArray = array();
    while ($row = $result->fetch_assoc()) {
        $userArray[] = $row;
    }
    echo json_encode($userArray);
} else {
    echo "No users found.";
}

$conn->close();
?>
