


<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $servername = "localhost";
    $username = "id21132821_session";
    $pass = "4444@Four";
    $dbname = "id21132821_info";
    
    $conn = new mysqli($servername, $username, $pass, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SELECT query to validate login
    $stmt = $conn->prepare("SELECT password FROM usertbl WHERE email=?");
    $stmt->bind_param("s", $email);

    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $response = array();

    if ($stmt->fetch() && password_verify($password, $hashedPassword)) {
         $response["success"] = true;
         $response["message"] = "Login successful";  
    } else {
        // Invalid credentials
          $response["success"] = false;
          $response["message"] = "Login failed. Please check your credentials.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method";
}

//header('Content-Type: application/json');
echo json_encode($response);
?>


