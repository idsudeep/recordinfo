<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $mobileno = $_POST['mobileno'];


  $servername = "localhost";
$username = "id21132821_session";
$password = "4444@Four";
$dbname = "id21132821_info";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the DELETE query
    $stmt = $conn->prepare("DELETE FROM usertbl WHERE mobileno=?");
    $stmt->bind_param("s", $mobileno);

    if ($stmt->execute()) {
        echo "User data deleted successfully";
    } else {
        echo "Error deleting user not found : " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method";
}
?>
