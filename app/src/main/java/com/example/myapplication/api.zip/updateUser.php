<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $userId = $_POST['userid'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $post = $_POST['post'];
    $doj = $_POST['doj'];

    // Validate and sanitize data if necessary

    // Create a database connection (adjust credentials accordingly)
$servername = "localhost";
$username = "id21132821_session";
$password = "4444@Four";
$dbname = "id21132821_info";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the UPDATE query
    $stmt = $conn->prepare("UPDATE usertbl SET fname=?, lname=?, mobileno=?, email=?, address=?, forpost=?, doj=? WHERE userid=?");
    $stmt->bind_param("sssssssi", $fname, $lname, $mobileno, $email, $address, $post, $doj, $userId);

    if ($stmt->execute()) {
        echo "User data updated successfully";
    } else {
        echo "Error updating user data: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method";
}
?>
