<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mname = $_POST['mname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $forpost = $_POST['forpost'];
    $dob = $_POST['dob'];
    $doj = $_POST['doj'];
    $gender = $_POST['gender'];

    // Validate and sanitize data if necessary

    // Database connection parameters
    $dsn = "mysql:host=localhost;dbname=id21132821_info";
    $username = "id21132821_session";
    $pass= "4444@Four";

    // Create a PDO connection
    try {
        $conn = new PDO($dsn, $username, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Hash and salt the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and execute the INSERT query using PDO
        $stmt = $conn->prepare("INSERT INTO usertbl (fname, lname, mname, email, password, address, mobileno, forpost, dob,doj, gender)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
        $stmt->execute([$fname, $lname, $mname, $email, $hashedPassword, $address, $phone, $forpost, $dob, $doj,$gender]);

        echo "User registered successfully";
    } catch (PDOException $e) {
       
       if($e->getCode() == 23000){echo "Email already exists";    
       }else{echo "Error registering user: " . $e->getMessage();}
    
    }
} else {
    echo "Invalid request method";
}
?>
