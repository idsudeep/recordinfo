
<?php
    $servername = "localhost";
    $username = "id21132821_session";
    $pass = "4444@Four";
    $dbname = "id21132821_info";
    
    $conn = new mysqli($servername, $username, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$dob = $_POST['dob'];
$newPassword = $_POST['password'];

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Check if user exists with the provided email and DOB
$sql = "SELECT * FROM usertbl WHERE email = '$email' AND dob = '$dob'";
$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    // Update the hashed password for the user
    $updateSql = "UPDATE usertbl SET password = '$hashedPassword' WHERE email = '$email'";
    
    if ($conn->query($updateSql) === TRUE) {
        $response["success"] = true;
        $response["message"] = "Password changed successfully";
    } else {
        $response["success"] = false;
        $response["message"] = "Error changing password: " . $conn->error;
    }
} else {
    // User doesn't exist or wrong credentials
    $response["success"] = false;
    $response["message"] = "Invalid email or date of birth";
}

// Close the database connection
$conn->close();

// header('Content-Type: application/json');
echo json_encode($response);
?>
